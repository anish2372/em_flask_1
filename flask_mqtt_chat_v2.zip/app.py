
from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
def index():
    return "<h1>Welcome! Go to /send or /receive</h1>"

@app.route('/send')
def sender():
    return render_template('sender.html')

@app.route('/receive')
def receiver():
    return render_template('receiver.html')

if __name__ == '__main__':
    app.run(debug=True)
